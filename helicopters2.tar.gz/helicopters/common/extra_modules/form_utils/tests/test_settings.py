INSTALLED_APPS = ('form_utils',)
DATABASE_ENGINE = 'sqlite3'
DATABASE_NAME = 'test'
